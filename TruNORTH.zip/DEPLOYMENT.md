# TruNORTH Deployment Guide

## Deploying to Vercel (Frontend)

### Step 1: Push Code to GitHub
```bash
# Initialize git if not already done
git init
git add .
git commit -m "Initial commit - TruNORTH Super App"

# Create a new repository on GitHub.com
# Then push your code:
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/TruNORTH.git
git push -u origin main
```

### Step 2: Deploy to Vercel

**Option A: Via Vercel Dashboard**
1. Go to [vercel.com](https://vercel.com) and sign up (free)
2. Click "Add New Project"
3. Import your GitHub repository
4. Configure:
   - Framework Preset: `Vite`
   - Build Command: `npm run build`
   - Output Directory: `dist`
5. Add Environment Variables:
   - `VITE_SUPABASE_URL` = Your Supabase project URL
   - `VITE_SUPABASE_ANON_KEY` = Your Supabase anon key
6. Click "Deploy"

**Option B: Via CLI**
```bash
# Install Vercel CLI
npm i -g vercel

# Login to Vercel
vercel login

# Deploy (follow prompts)
vercel

# For production deployment
vercel --prod
```

### Step 3: Configure Custom Domain (Optional)
1. Go to Vercel Dashboard → Your Project → Settings → Domains
2. Add your custom domain
3. Update DNS records as instructed

---

## Deploying Backend (Optional)

For the Node.js/Express backend, use **Railway** or **Render**:

### Deploy to Railway
1. Go to [railway.app](https://railway.app) and sign up (free)
2. Click "New Project" → "Deploy from GitHub repo"
3. Select your TruNORTH repository
4. Add Environment Variables:
   - `DATABASE_URL` = Your Supabase connection string
   - `JWT_SECRET` = Your secret key
   - `PORT` = 3000
5. Click "Deploy"

### Deploy to Render
1. Go to [render.com](https://render.com) and sign up (free)
2. Click "New +" → "Web Service"
3. Connect your GitHub repository
4. Configure:
   - Build Command: `cd server && npm install`
   - Start Command: `cd server && npm start`
5. Add Environment Variables:
   - `DATABASE_URL` = Your Supabase connection string
   - `JWT_SECRET` = Your secret key
   - `PORT` = 3000
6. Click "Create Web Service"

---

## Environment Variables

### Frontend (.env.production)
```
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key
VITE_API_URL=https://your-backend.railway.app
```

### Backend (.env)
```
DATABASE_URL=postgresql://user:password@host:5432/database
JWT_SECRET=your-super-secret-jwt-key
PORT=3000
CORS_ORIGIN=https://your-vercel-domain.vercel.app
```

---

## Free Tier Limits

### Vercel (Frontend)
- **Bandwidth**: 100GB/month
- **Sites**: Unlimited
- **Build Time**: 100 hours/month
- **SSL**: Free custom domains

### Railway (Backend)
- **Compute**: $5 credit/month (~100 hours on shared tier)
- **Database**: 1GB storage (if using Railway PostgreSQL)

### Supabase (Database)
- **Database**: 500MB
- **File Storage**: 1GB
- **Auth**: Unlimited users
- **API Requests**: Unlimited

---

## After Deployment

1. **Update Supabase CORS**: Add your Vercel domain to Supabase → API → CORS
2. **Update Backend CORS**: Add your Vercel domain to backend CORS settings
3. **Test All Features**:
   - User registration/login
   - AI chat
   - Wallet operations
   - All service pages

---

## Troubleshooting

### Build Fails
- Check `npm run build` works locally
- Ensure all dependencies are in `package.json`

### CORS Errors
- Add your domain to backend CORS configuration
- Add domain to Supabase CORS settings

### API Not Connecting
- Verify environment variables are set
- Check backend is deployed and running

---

## Quick Deploy Checklist

- [ ] Code pushed to GitHub
- [ ] Vercel account created
- [ ] Project connected to Vercel
- [ ] Environment variables added
- [ ] Build successful on Vercel
- [ ] Supabase CORS updated
- [ ] Backend deployed (if using)
- [ ] All features tested
